# File Format Convertor
from PIL import Image

# Load the PNG you downloaded from Icons8
img = Image.open("./icons8-gear-48.png")

# Define the standard Windows icon sizes
icon_sizes = [(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]

# Save as a multi-layer ICO
img.save("app.ico", sizes=icon_sizes)
print("Professional multi-layer app.ico created.")