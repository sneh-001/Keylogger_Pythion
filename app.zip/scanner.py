import socket
import random
import time

def stealth_check(target_ip, ports):
    random.shuffle(ports)
    print(f"[*] Starting quiet scan on {target_ip}...")
    
    for port in ports:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(1.5)
            result = s.connect_ex((target_ip, port))
            if result == 0:
                print(f"[+] Port {port} is OPEN")
            s.close()
            
        except Exception as e:
            pass
        wait_time = random.uniform(2.0, 5.0)
        time.sleep(wait_time)

if __name__ == "__main__":
    target = "74.225.198.123"
    important_ports = [21, 22, 80, 135, 139, 443, 445, 3389]
    stealth_check(target, important_ports)
